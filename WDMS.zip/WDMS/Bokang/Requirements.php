<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Requirements</title>
        <link href="MyCSS.css" rel="stylesheet">
    </head>
    <body>

        <h3>Your password should meet the following requirements:</h3>

        <ol type="1">
            <li>May contain letter and numbers</li>
            <li>Must contain at least 1 number and 1 letter</li>
            <li>May contain any of these characters: !@#$%</li>
            <li>Must be 8-16 characters</li>
        </ol>



        <?php
        // put your code here
        ?>
    </body>
</html>
